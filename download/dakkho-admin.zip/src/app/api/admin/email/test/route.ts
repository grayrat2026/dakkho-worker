import { NextRequest, NextResponse } from 'next/server';
import { sendEmail, sendTestEmail } from '@/lib/resend';
import { db } from '@/lib/db';
import { logAudit } from '@/lib/audit';

export async function POST(req: NextRequest) {
  try {
    const { to, subject, html, template } = await req.json();

    let result;
    if (template === 'test') {
      result = await sendTestEmail(to);
    } else {
      result = await sendEmail(to, subject, html);
    }

    await db.emailLog.create({
      data: {
        to,
        subject: subject || 'DAKKHO Admin - Test Email',
        template: template || 'custom',
        status: 'sent',
      },
    });

    const adminId = req.cookies.get('dakkho-admin-session')?.value || 'unknown';
    await logAudit(adminId, 'SEND_EMAIL', 'email', undefined, { to, subject });

    return NextResponse.json({ success: true, result });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : 'Unknown error';

    try {
      await db.emailLog.create({
        data: {
          to: 'unknown',
          subject: 'Failed email',
          status: 'failed',
          error: message,
        },
      });
    } catch {}

    return NextResponse.json({ error: message }, { status: 500 });
  }
}
